package dao;

import entity.Cases;

public interface CasesDaoInterface{
	  public void putCaseToArray();

	  /**
	     * Adds a new case to the database.
	     *
	     * @param cases The case object to be added.
	     */
	  public void addCase(Cases cases);
}
