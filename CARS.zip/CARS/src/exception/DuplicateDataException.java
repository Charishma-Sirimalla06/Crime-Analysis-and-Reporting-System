package exception;

public class DuplicateDataException extends Exception {

	public DuplicateDataException() {
		System.err.println("Duplicate Data Exception");
	}

	@Override
	public String toString() {
		return "Duplicate Data Entered!!";
	}
	
}